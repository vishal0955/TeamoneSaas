import React from 'react'

const ClientDashboard = () => {
  return (
    <div>
      clinent
    </div>
  )
}

export default ClientDashboard
