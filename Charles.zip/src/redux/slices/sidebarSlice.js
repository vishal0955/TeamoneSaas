// import { createSlice } from "@reduxjs/toolkit";

//  const sidebarSlice = createSlice(
//     name: "sidebar",
//     initialState: {
//         open: false,
//     },
//     reducers: {
//         toggleSidebar: (state) => {


//     }

//  )