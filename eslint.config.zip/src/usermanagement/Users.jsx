import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';

const Users = () => {
  const users = [
    { id: 1, name: 'Anthony Lewis', email: 'anthony@example.com', createdDate: '12 Sep 2024', role: 'Employee', status: 'Active' },
    { id: 2, name: 'Sarah Johnson', email: 'sarah@example.com', createdDate: '15 Sep 2024', role: 'Client', status: 'Active' },
    { id: 3, name: 'Michael Chen', email: 'michael@example.com', createdDate: '18 Sep 2024', role: 'Employee', status: 'Inactive' },
    // Add more users as needed
  ];

  return (
    <div className="container mt-4">
      <h2>Users List</h2>
      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Created Date</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.createdDate}</td>
                <td>{user.role}</td>
                <td>{user.status}</td>
                <td>✅</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-3">
        Showing 1 to {users.length} of 50 entries
      </div>
    </div>
  );
};

export default Users;