import React from 'react'

const EmployeeDashboard = () => {
  return (
    <div>
      employee
    </div>
  )
}

export default EmployeeDashboard
