import React from 'react'

const ManagerDashboard = () => {
  return (
    <div>
      manager
    </div>
  )
}

export default ManagerDashboard
