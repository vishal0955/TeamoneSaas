import React from "react";

const SuperAdminDashboard = () => {
  return <div>super</div>;
};

export default SuperAdminDashboard;
